import json,csv,hashlib,re,math
from collections import defaultdict,Counter
from pathlib import Path
import numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests

BASE=Path('/mnt/data')
res=json.load(open(BASE/'social_reasoning_results.json'))
models=list(res['model_results'].keys())
# get sampled question scores from first model and validate IDs
sample_ids=res['model_results'][models[0]]['question_ids']
assert len(sample_ids)==307 and len(set(sample_ids))==307
for m in models:
    assert res['model_results'][m]['question_ids']==sample_ids
    assert len(res['model_results'][m]['question_scores'])==307

# Build question -> qid hash from canonical file exactly following revised notebook.
qtext_to_id={}
source_group_counts=Counter()
for line in open(BASE/'recovered_inputs/ProlificAI.jsonl',encoding='utf-8'):
    d=json.loads(line)
    q=str(d.get('question','')).strip()
    qid=hashlib.sha256(q.encode('utf-8')).hexdigest()[:16]
    qtext_to_id[q]=qid
    source_group_counts[q]+=1
assert len(qtext_to_id)==955, len(qtext_to_id)
assert all(n==4 for n in source_group_counts.values())

# read bundle question ids and translate to hashes
with open(BASE/'paraphrase_bundle/unique_questions.csv',newline='',encoding='utf-8') as f:
    uq=list(csv.DictReader(f))
qcode_to_hash={r['question_id']:hashlib.sha256(r['question'].strip().encode('utf-8')).hexdigest()[:16] for r in uq}
question_hash_to_code={v:k for k,v in qcode_to_hash.items()}
assert len(qcode_to_hash)==len(uq)

with open(BASE/'paraphrase_bundle/reviewed_pair_labels.csv',newline='',encoding='utf-8') as f:
    labels=list(csv.DictReader(f))
with open(BASE/'paraphrase_bundle_audit/second_pass_review_of_20_accepted_pairs.csv',newline='',encoding='utf-8') as f:
    pass2=list(csv.DictReader(f))
second_by_pair={r['pair_id']:r['conservative_second_pass_decision'] for r in pass2}

# Convert accepted edges into hashed ids
all_edges=[]; strict_edges=[]
for r in labels:
    if r['decision']=='PARAPHRASE':
        a=qcode_to_hash[r['question_id_a']]; b=qcode_to_hash[r['question_id_b']]
        all_edges.append((a,b,r['pair_id'],r['question_id_a'],r['question_id_b']))
        if second_by_pair.get(r['pair_id'], 'PARAPHRASE')=='PARAPHRASE':
            strict_edges.append((a,b,r['pair_id'],r['question_id_a'],r['question_id_b']))

def components(edges):
    adj=defaultdict(set)
    for a,b,*_ in edges: adj[a].add(b);adj[b].add(a)
    seen=set(); comps=[]
    for node in adj:
        if node in seen: continue
        stack=[node];seen.add(node); comp=[]
        while stack:
            v=stack.pop();comp.append(v)
            for u in adj[v]:
                if u not in seen: seen.add(u);stack.append(u)
        comps.append(sorted(comp))
    return comps

all_comps=components(all_edges)
strict_comps=components(strict_edges)
sample_set=set(sample_ids)
screened_hashes=set(qcode_to_hash.values())
summary={
    'models':models,
    'score_metadata_seed':res['metadata'].get('random_seed'),
    'score_metadata_questions':res['metadata'].get('n_questions_sampled'),
    'screened_questions':len(screened_hashes),
    'sampled_questions':len(sample_set),
    'sampled_screened':len(sample_set & screened_hashes),
    'sampled_not_screened':len(sample_set - screened_hashes),
    'first_pass_paraphrase_edges':len(all_edges),
    'first_pass_components':len(all_comps),
    'first_pass_component_sizes':sorted([len(x) for x in all_comps], reverse=True),
    'strict_pass_paraphrase_edges':len(strict_edges),
    'strict_pass_components':len(strict_comps),
    'strict_pass_component_sizes':sorted([len(x) for x in strict_comps], reverse=True),
    'first_pass_edges_both_sampled':sum(1 for a,b,*_ in all_edges if a in sample_set and b in sample_set),
    'strict_edges_both_sampled':sum(1 for a,b,*_ in strict_edges if a in sample_set and b in sample_set),
}

def build_samplescores():
    return {m:dict(zip(res['model_results'][m]['question_ids'],res['model_results'][m]['question_scores'])) for m in models}
scores=build_samplescores()

def holm(vals): return multipletests(vals,method='holm')[1].tolist()

def compare(dataset, label):
    # dataset list of tuples (unit id, original sampled question hashes in unit)
    # Scores within a multi-question component are averaged by model; paired cluster unit is component
    dat={m:np.array([np.mean([scores[m][qid] for qid in members]) for _,members in dataset],float) for m in models}
    rows=[]
    pvals=[]
    for i,m1 in enumerate(models):
      for m2 in models[i+1:]:
        diff=dat[m1]-dat[m2]
        tt,p=stats.ttest_rel(dat[m1],dat[m2])
        sd=float(np.std(diff,ddof=1))
        dz=float(np.mean(diff)/sd) if sd>0 else np.nan
        # percentile paired cluster bootstrap CI for mean paired difference
        rng=np.random.default_rng(42+len(dataset)+i*13+models.index(m2))
        inds=rng.integers(0,len(diff),size=(20000,len(diff)))
        bm=diff[inds].mean(axis=1)
        lo,hi=np.percentile(bm,[2.5,97.5])
        rows.append({'analysis':label,'n_independent_units':len(dataset),'comparison':f'{m1} vs {m2}', 'model1':m1,'model2':m2,
                     'mean_loss_diff_m1_minus_m2':float(np.mean(diff)), 'ci95_low':float(lo),'ci95_high':float(hi),
                     'cohens_dz_paired':dz,'t_stat':float(tt),'p_raw':float(p)})
        pvals.append(p)
    adj=holm(pvals)
    for row,padj in zip(rows,adj): row['p_holm']=float(padj);row['significant_holm_05']=bool(padj<.05)
    return dat,rows

# units baseline
baseline=[(q,[q]) for q in sample_ids]
all_rows=[]
base_dat,base_rows=compare(baseline,'Original 307 questions')
all_rows += base_rows

# function to build paraphrase components in sampled sample; each connected component with at least one sampled member forms one unit, otherwise ignore
for label,edges,comps in [('Conservative second-pass 10 accepted links',strict_edges,strict_comps),('Initial pass all 20 accepted links',all_edges,all_comps)]:
    units=[]; covered=set()
    for comp_idx,comp in enumerate(comps):
        members=sorted(set(comp)&sample_set)
        if members:
            units.append((f'paraphrase_component_{comp_idx+1}',members));covered.update(members)
    units.extend((q,[q]) for q in sample_ids if q not in covered)
    dat,rows=compare(units,label+' (collapse sampled members per component)')
    all_rows += rows
    summary[label]= {
       'n_components_with_sampled_members':sum(1 for c in comps if set(c)&sample_set),
       'n_components_with_2plus_sampled_members':sum(1 for c in comps if len(set(c)&sample_set)>=2),
       'sampled_questions_in_components':len(covered),
       'sampled_questions_in_components_2plus':sum(len(set(c)&sample_set) for c in comps if len(set(c)&sample_set)>=2),
       'analysis_units_after_collapse':len(units),
       'components_in_sample':[
          {'component':i+1,'members_sampled':[question_hash_to_code.get(q,q) for q in sorted(set(c)&sample_set)],
           'questions':[next((r['question'] for r in uq if r['question_id']==question_hash_to_code.get(q)), '') for q in sorted(set(c)&sample_set)]}
          for i,c in enumerate(comps) if set(c)&sample_set
       ]
    }

# remove sampled items covered by any accepted component (two definitions) and run inference on remaining individuals
for label,edges,comps in [('Conservative second-pass 10 accepted links',strict_edges,strict_comps),('Initial pass all 20 accepted links',all_edges,all_comps)]:
    covered=set(q for c in comps for q in c if q in sample_set)
    remains=[(q,[q]) for q in sample_ids if q not in covered]
    dat,rows=compare(remains,label+' (exclude all sampled questions in detected components)')
    all_rows += rows
    summary[label]['n_units_after_exclusion']=len(remains)
    summary[label]['excluded_sampled_questions']=len(covered)

# identify all sampled/unsampled links in accepted edge list, with question text, scores
edge_rows=[]
for passname,edges in [('initial_pass',all_edges),('conservative_second_pass',strict_edges)]:
  for a,b,pid,qa,qb in edges:
    sa,sb=a in sample_set,b in sample_set
    edge_rows.append({'review_pass':passname,'pair_id':pid,'question_id_a':qa,'question_id_b':qb,
      'sampled_a':sa,'sampled_b':sb,'both_in_primary_sample':sa and sb,
      'question_a':next((r['question'] for r in uq if r['question_id']==qa),''),
      'question_b':next((r['question'] for r in uq if r['question_id']==qb),''),
      **{f'{m}_score_a':scores[m].get(a,np.nan) for m in models},
      **{f'{m}_score_b':scores[m].get(b,np.nan) for m in models}})

# report individual model means and exact saved-pairwise comparisons
summary['full_sample_model_means']={m:float(np.mean(list(scores[m].values()))) for m in models}
summary['original_saved_pairwise_stats']=res.get('pairwise_statistics',{})
summary['qid_sample_consistency_check']={'same_ids_all_models': all(res['model_results'][m]['question_ids']==sample_ids for m in models), 'unique_ids':len(set(sample_ids))}

# Save outputs
out=BASE/'current_paraphrase_sensitivity'
out.mkdir(exist_ok=True)
json.dump(summary,open(out/'summary.json','w'),indent=2,ensure_ascii=False)
with open(out/'model_comparison_sensitivity.csv','w',newline='',encoding='utf-8') as f:
    cols=list(all_rows[0].keys()); w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(all_rows)
with open(out/'accepted_edges_sample_overlap.csv','w',newline='',encoding='utf-8') as f:
    cols=list(edge_rows[0].keys()); w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(edge_rows)

# Create clean report
lines=[]
lines += ['# Exploratory paraphrase sensitivity analysis using current files','',
'## Data scope and limitation','',
'- The saved score file contains 307 question-level scores for each of four models, using random seed 42. It uses SHA-256-derived question IDs and the four models share the same 307 IDs.',
'- The available paraphrase review covers only the first 424 of 955 unique source questions. The sample intersects this screened subset in %d questions; %d sampled questions are not screened.'%(summary['sampled_screened'],summary['sampled_not_screened']),
'- Thus, this is a partial sensitivity check, not a complete correction for paraphrase dependence across all 955 questions. No conclusion about the absence of additional paraphrases is justified.',
'- There is a provenance mismatch: the revised notebook in the current files specifies seed 2026, while the uploaded score JSON states seed 42. I analyzed the 307 questions present in the score JSON rather than silently substituting a different sample.',
'', '## Original primary comparison','',
'The saved primary analysis reports all six model comparisons significant after Holm correction. Those are the original, unadjusted question-level comparisons.',
'', '## Sensitivity procedures','',
'1. **Conservative collapse:** use only links that remained PARAPHRASE after the conservative second pass of the 20 initially accepted edges; all sampled members of a connected component are averaged into one unit.',
'2. **Broader collapse:** repeat using all 20 first-pass PARAPHRASE edges, without the second-pass filtering.',
'3. **Exclusion checks:** remove all sampled questions that belong to the detected components and rerun the six comparisons. This is intentionally conservative but may discard a sampled question whose paraphrase partner is outside the 307-question sample.',
'', 'The paraphrase decisions are model-assisted semantic judgments, not an independently adjudicated gold standard. The strict second pass also reviewed only the 20 first-pass positives, not every pair labelled RELATED_NOT_PARAPHRASE.',
'', '## Sensitivity results','']
# Add concise rows all analyses x comparisons
for analysis in dict.fromkeys(x['analysis'] for x in all_rows):
 lines.append('### '+analysis)
 lines.append('')
 lines.append('| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |')
 lines.append('|---|---:|---:|---:|---:|')
 for r in [x for x in all_rows if x['analysis']==analysis]:
   lines.append(f"| {r['comparison']} | {r['n_independent_units']} | {r['mean_loss_diff_m1_minus_m2']:.4f} | [{r['ci95_low']:.4f}, {r['ci95_high']:.4f}] | {r['p_holm']:.3g} |")
 lines.append('')
lines += ['## Sampled questions implicated by the current review','',
'Question-level and edge-level membership is in `accepted_edges_sample_overlap.csv`. The analysis can detect only duplicates among candidate questions already present in the screened prefix. See `model_comparison_sensitivity.csv` for the full statistical outputs.',
'', '## Recommended interpretation','',
'Treat this as a limited sensitivity check. Report whether the ranking and broad pairwise conclusions are stable in the checked subset, but do not describe the analysis as a full-dataset paraphrase correction. The missing coverage of 531 questions prevents that claim. Resolve the seed discrepancy before treating the analysis as aligned with the revised notebook.',
'']
(out/'report.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['original_saved_pairwise_stats']},indent=2)[:14000])
print('\nRESULT TABLES')
for analysis in dict.fromkeys(x['analysis'] for x in all_rows):
 print('\n'+analysis)
 for r in [x for x in all_rows if x['analysis']==analysis]:
  print(r['comparison'],r['n_independent_units'],round(r['mean_loss_diff_m1_minus_m2'],4),[round(r['ci95_low'],4),round(r['ci95_high'],4)],'Holm',r['p_holm'])
print('\nOutputs', list(str(p) for p in out.iterdir()))
