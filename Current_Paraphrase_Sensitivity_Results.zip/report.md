# Exploratory paraphrase sensitivity analysis using current files

## Data scope and limitation

- The saved score file contains 307 question-level scores for each of four models, using random seed 42. It uses SHA-256-derived question IDs and the four models share the same 307 IDs.
- The available paraphrase review covers only the first 424 of 955 unique source questions. The sample intersects this screened subset in 140 questions; 167 sampled questions are not screened.
- Thus, this is a partial sensitivity check, not a complete correction for paraphrase dependence across all 955 questions. No conclusion about the absence of additional paraphrases is justified.
- There is a provenance mismatch: the revised notebook in the current files specifies seed 2026, while the uploaded score JSON states seed 42. I analyzed the 307 questions present in the score JSON rather than silently substituting a different sample.

## Original primary comparison

The saved primary analysis reports all six model comparisons significant after Holm correction. Those are the original, unadjusted question-level comparisons.

## Sensitivity procedures

1. **Conservative collapse:** use only links that remained PARAPHRASE after the conservative second pass of the 20 initially accepted edges; all sampled members of a connected component are averaged into one unit.
2. **Broader collapse:** repeat using all 20 first-pass PARAPHRASE edges, without the second-pass filtering.
3. **Exclusion checks:** remove all sampled questions that belong to the detected components and rerun the six comparisons. This is intentionally conservative but may discard a sampled question whose paraphrase partner is outside the 307-question sample.

The paraphrase decisions are model-assisted semantic judgments, not an independently adjudicated gold standard. The strict second pass also reviewed only the 20 first-pass positives, not every pair labelled RELATED_NOT_PARAPHRASE.

## Sensitivity results

### Original 307 questions

| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |
|---|---:|---:|---:|---:|
| Qwen3-8B vs Qwen3-8B-Base | 307 | 0.2935 | [0.2839, 0.3032] | 3.89e-168 |
| Qwen3-8B vs llama-3.1-8b-base | 307 | 0.2353 | [0.2224, 0.2480] | 1.19e-110 |
| Qwen3-8B vs llama-3.1-8B-instruct | 307 | 0.1376 | [0.1262, 0.1489] | 2.04e-71 |
| Qwen3-8B-Base vs llama-3.1-8b-base | 307 | -0.0582 | [-0.0677, -0.0487] | 2.75e-27 |
| Qwen3-8B-Base vs llama-3.1-8B-instruct | 307 | -0.1559 | [-0.1654, -0.1465] | 3.2e-100 |
| llama-3.1-8b-base vs llama-3.1-8B-instruct | 307 | -0.0977 | [-0.1055, -0.0899] | 6.09e-73 |

### Conservative second-pass 10 accepted links (collapse sampled members per component)

| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |
|---|---:|---:|---:|---:|
| Qwen3-8B vs Qwen3-8B-Base | 306 | 0.2930 | [0.2834, 0.3027] | 4.36e-168 |
| Qwen3-8B vs llama-3.1-8b-base | 306 | 0.2348 | [0.2220, 0.2478] | 2.99e-110 |
| Qwen3-8B vs llama-3.1-8B-instruct | 306 | 0.1369 | [0.1256, 0.1481] | 1.97e-71 |
| Qwen3-8B-Base vs llama-3.1-8b-base | 306 | -0.0582 | [-0.0677, -0.0486] | 4.12e-27 |
| Qwen3-8B-Base vs llama-3.1-8B-instruct | 306 | -0.1560 | [-0.1655, -0.1465] | 6.72e-100 |
| llama-3.1-8b-base vs llama-3.1-8B-instruct | 306 | -0.0979 | [-0.1057, -0.0901] | 5.87e-73 |

### Initial pass all 20 accepted links (collapse sampled members per component)

| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |
|---|---:|---:|---:|---:|
| Qwen3-8B vs Qwen3-8B-Base | 305 | 0.2932 | [0.2835, 0.3029] | 1.6e-167 |
| Qwen3-8B vs llama-3.1-8b-base | 305 | 0.2349 | [0.2220, 0.2478] | 7.35e-110 |
| Qwen3-8B vs llama-3.1-8B-instruct | 305 | 0.1372 | [0.1260, 0.1484] | 2.39e-71 |
| Qwen3-8B-Base vs llama-3.1-8b-base | 305 | -0.0582 | [-0.0678, -0.0487] | 5.61e-27 |
| Qwen3-8B-Base vs llama-3.1-8B-instruct | 305 | -0.1560 | [-0.1656, -0.1466] | 1.83e-99 |
| llama-3.1-8b-base vs llama-3.1-8B-instruct | 305 | -0.0978 | [-0.1056, -0.0899] | 9.38e-73 |

### Conservative second-pass 10 accepted links (exclude all sampled questions in detected components)

| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |
|---|---:|---:|---:|---:|
| Qwen3-8B vs Qwen3-8B-Base | 299 | 0.2933 | [0.2836, 0.3032] | 2.24e-164 |
| Qwen3-8B vs llama-3.1-8b-base | 299 | 0.2349 | [0.2218, 0.2479] | 9.76e-108 |
| Qwen3-8B vs llama-3.1-8B-instruct | 299 | 0.1363 | [0.1248, 0.1475] | 1.1e-69 |
| Qwen3-8B-Base vs llama-3.1-8b-base | 299 | -0.0584 | [-0.0682, -0.0488] | 1.63e-26 |
| Qwen3-8B-Base vs llama-3.1-8B-instruct | 299 | -0.1570 | [-0.1667, -0.1475] | 7.8e-98 |
| llama-3.1-8b-base vs llama-3.1-8B-instruct | 299 | -0.0987 | [-0.1065, -0.0905] | 6.38e-72 |

### Initial pass all 20 accepted links (exclude all sampled questions in detected components)

| Comparison (model 1 − model 2) | Units | Mean loss difference | 95% bootstrap CI | Holm-adjusted p |
|---|---:|---:|---:|---:|
| Qwen3-8B vs Qwen3-8B-Base | 294 | 0.2936 | [0.2837, 0.3034] | 1.69e-161 |
| Qwen3-8B vs llama-3.1-8b-base | 294 | 0.2353 | [0.2222, 0.2484] | 1.07e-105 |
| Qwen3-8B vs llama-3.1-8B-instruct | 294 | 0.1370 | [0.1254, 0.1484] | 1.75e-68 |
| Qwen3-8B-Base vs llama-3.1-8b-base | 294 | -0.0583 | [-0.0680, -0.0485] | 1.03e-25 |
| Qwen3-8B-Base vs llama-3.1-8B-instruct | 294 | -0.1567 | [-0.1665, -0.1470] | 9.5e-96 |
| llama-3.1-8b-base vs llama-3.1-8B-instruct | 294 | -0.0984 | [-0.1063, -0.0904] | 8.41e-71 |

## Sampled questions implicated by the current review

Question-level and edge-level membership is in `accepted_edges_sample_overlap.csv`. The analysis can detect only duplicates among candidate questions already present in the screened prefix. See `model_comparison_sensitivity.csv` for the full statistical outputs.

## Recommended interpretation

Treat this as a limited sensitivity check. Report whether the ranking and broad pairwise conclusions are stable in the checked subset, but do not describe the analysis as a full-dataset paraphrase correction. The missing coverage of 531 questions prevents that claim. Resolve the seed discrepancy before treating the analysis as aligned with the revised notebook.
