# Counting audit: primary sample and screening bundle

## Primary sample overlap

The uploaded `social_reasoning_results.json` contains 307 unique question IDs. I verified that all four model results use the same 307 IDs. I matched each ID to the canonical question text using the exact ID construction in the scoring notebook: the first 16 hexadecimal characters of SHA-256 applied to the stripped question text. I then joined those IDs against the 424 texts in `unique_questions.csv`.

- Primary questions present in the screening bundle: **140**
- Primary questions absent from the screening bundle: **167**
- Total primary questions: **307**

The counts remain **140 / 167** when restricting the screen to question groups with all four source records. The one partial group is not part of the primary sample.

## Why 1,693 source records map to 424 distinct questions

The screening extract contains 1,693 rows. Its group-size distribution is:

- **423 questions × 4 records = 1,692 records**
- **1 question × 1 record = 1 record**
- Total: **1,693 records across 424 distinct question texts**

The partial group is `Q0424`: “How do you react when people aren't kind to you or others around you?” Only source record 1,693 appears in the extract; its other three records would be source records 1,694–1,696. The canonical source confirms that the full group has four records. The question text itself is present in the candidate screen, which operates on question texts, not response records. `Q0424` is not among the 307 primary sample questions, so it does not change the overlap count.

## Seed discrepancy

The saved score JSON reports random seed **42**, while the revised notebook currently specifies **2026**. The counts in this audit describe the exact 307 IDs in the uploaded score JSON. Do not use the alternative overlap count from a reconstructed seed-2026 sample to describe these scores.

A one-row-per-primary-question trace is in `question_overlap_audit.csv`.
