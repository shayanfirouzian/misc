# Suggested manuscript/reviewer wording

## Main-text limitation and sensitivity result

We examined whether the model comparison was sensitive to semantically similar Social Reasoning questions using the available paraphrase-screening results. The available screening covered 424 of the dataset's 955 unique questions, so this analysis is exploratory rather than a full-dataset correction. In the uploaded 307-question score file, 140 questions appeared in the screening bundle and 167 did not. Of 20 candidate pairs initially classified as paraphrases, a conservative second review retained 10. Collapsing the sampled members of these accepted paraphrase groups into single analysis units left the model ranking unchanged, and all six pairwise model comparisons remained significant after Holm correction. A broader analysis using all 20 initial pair labels, and exclusion analyses removing sampled questions in detected paraphrase groups, produced the same ordering and significance conclusions. These results suggest that the detected paraphrases do not explain the main comparison pattern. However, because more than half of the sampled questions were not covered by the available screening, the analysis cannot rule out effects from paraphrases that have not yet been reviewed.

## Reviewer-response wording

Thank you for raising the possibility that semantically overlapping questions could inflate the effective sample size. We performed a sensitivity analysis using the paraphrase labels currently available. The model ordering and all six Holm-adjusted pairwise conclusions were unchanged after collapsing detected paraphrase groups or excluding sampled questions belonging to those groups. We have treated this as a limited sensitivity check, not as a complete paraphrase-adjusted analysis: the screening bundle contains 424 distinct question texts out of 955, including 140 of the 307 questions in the uploaded score file. The source-record extract has 423 complete four-record question groups plus one partial group; that partial question is not in the primary sample. We therefore cannot rule out effects from unreviewed questions. We also identified a reproducibility discrepancy that needs to be resolved before describing these scores as the results of the revised notebook: the saved JSON reports sampling seed 42, whereas the notebook specifies seed 2026.

## Short interpretation

The model comparison is robust to the paraphrases detected in the available partial screen. This does not establish robustness to all paraphrases in the full dataset.


## Counting clarification

For the uploaded `social_reasoning_results.json`, the consistent overlap counts are **140 present in the screening bundle and 167 absent** (307 total). The source-record extract has 1,693 rows: 423 full four-record groups plus one row from the final question, `Q0424`. That question is not in the primary sample. The saved score metadata says seed 42; the revised notebook specifies seed 2026, so the report uses the 307 IDs that are actually present in the uploaded score JSON.
