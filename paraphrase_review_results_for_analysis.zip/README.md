# Semantic paraphrase candidate screen

- Input records used: 1693
- Unique normalized questions: 424
- Candidate pairs for frontier-model review: 1066
- Review batches (40 pairs per batch): 27
- Embedding model: sentence-transformers/all-mpnet-base-v2

## Files
- `unique_questions.csv`: one row per exact question after Unicode/case/whitespace normalization.
- `source_record_mapping.csv`: maps every source record to its question ID and source order.
- `candidate_pairs.csv` / `.jsonl`: pairwise candidates, with embedding and lexical scores.
- `review_batches/`: small JSONL batches to pass to a frontier model using `frontier_model_review_prompt.md`.
- `screening_summary.json`: settings and counts.

## Interpretation
This script does not automatically cluster questions or call a pair a paraphrase. The embedding and lexical scores are retrieval signals used to find candidate pairs. A frontier model should label each pair using the supplied decision rules. After the labels are returned, combine the batch outputs and provide them, plus `unique_questions.csv`, `candidate_pairs.csv`, and `source_record_mapping.csv`, for a conflict-checked cluster assignment and reanalysis of Social Reasoning results.
