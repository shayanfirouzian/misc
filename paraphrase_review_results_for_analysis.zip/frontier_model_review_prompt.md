# Prompt: review candidate question pairs for paraphrase status

You are reviewing candidate pairs of questions from a social-scenario preference dataset. The pairs were proposed by an embedding/lexical-similarity screen. **Similarity scores are candidate-retrieval clues, not proof of paraphrase.** Your task is to judge whether the two question texts ask for substantively the same underlying answer.

For every input pair, assign exactly one label:

- `PARAPHRASE`: the same underlying scenario/question and same essential information need; differences are mainly wording, syntax, or minor non-material phrasing.
- `RELATED_NOT_PARAPHRASE`: same broad topic, but the task, requested action, important context, actors/relationships, constraints, or expected answer could materially differ.
- `NOT_PARAPHRASE`: meaning or task is different, even if the embedding score is high.
- `UNCERTAIN`: the pair cannot be reliably judged from the text alone.

Rules:
1. Compare only the question text. Do not use chosen/rejected responses or outside knowledge.
2. Do not merge questions merely because they share a theme (e.g., friendship, work, health, safety, or identity).
3. Treat changes in the requested action, decision, target person, relevant constraint, polarity, temporal situation, or expected answer type as important unless clearly immaterial.
4. If the questions could reasonably require materially different answers, use `RELATED_NOT_PARAPHRASE`, not `PARAPHRASE`.
5. Similarity scores do not determine your label. A high score may still be a false positive; a lower score may still be a paraphrase.
6. Be conservative. It is better to mark an uncertain pair as `UNCERTAIN` than to merge distinct scenarios.
7. Preserve every `pair_id` and both question IDs exactly. Review every input row once.

## Required output format
Return **only JSONL**, with exactly one JSON object per input pair and no Markdown fences or introductory text. Each object must have these fields:

`pair_id`, `question_id_a`, `question_id_b`, `decision`, `confidence`, `reason`

`decision` must be one of `PARAPHRASE`, `RELATED_NOT_PARAPHRASE`, `NOT_PARAPHRASE`, `UNCERTAIN`. `confidence` is an integer from 0 to 100. `reason` must be one short sentence identifying the key semantic match or difference. Do not create cluster IDs yet; this task labels pair relationships only.

Before returning, verify that every input `pair_id` appears exactly once and that no IDs were invented or omitted.

## Batch to review
Paste or attach the complete contents of one `review_batch_NNN.jsonl` file below this line. Review only that batch.
